import unittest

class TestCreateParser(unittest.TestCase):
    def test_create_parser(self):
        # self.assertEqual(expected, create_parser())
        assert False # TODO: implement your test here

class TestParsefunc(unittest.TestCase):
    def test_parsefunc(self):
        #self.assertEqual(expected, parsefunc(args))
        assert False # TODO: implement your test here

class TestMain(unittest.TestCase):
    def test_main(self):
        # self.assertEqual(expected, main())
        assert False # TODO: implement your test here

if __name__ == '__main__':
    unittest.main()
