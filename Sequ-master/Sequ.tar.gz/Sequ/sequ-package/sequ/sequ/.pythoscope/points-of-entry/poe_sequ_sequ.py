#!/usr/bin/python
# .pythoscope/points-of-entry/poe_sequ_sequ.py
from sequ import Sequ as s
s(1, 10).sequ()
