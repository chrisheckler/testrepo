import unittest
from sequ import Sequ

class TestSequ(unittest.TestCase):
    def test___init__(self):
        # sequ = Sequ(minimum, maximum)
        assert False # TODO: implement your test here

    def test_sequ_ret(self):
        # sequ = Sequ(minimum, maximum)
        # self.assertEqual(expected, sequ.sequ_ret())
        assert False # TODO: implement your test here

    def test_creation_with_maximum_equal_10_and_minimum_equal_1(self):
        sequ = Sequ(1, 10)
#Makesureitdoesn'traiseanyexceptions.

if __name__ == '__main__':
    unittest.main()
